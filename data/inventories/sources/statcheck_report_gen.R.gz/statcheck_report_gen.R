dat <- read.csv('statcheck_dataset.csv', stringsAsFactors = FALSE)

uniq <- unique(dat$Source)

for (i in 1:length(uniq))
{
  sel <- dat[dat$Source == uniq[i] &
               !is.na(dat$Source) &
               !is.na(dat$Error) & 
               !is.na(dat$DecisionError) & 
               !is.na(dat$Raw), ]
  
  num_res <- dim(sel)[1]
  
  num_error <- sum(sel$Error, na.rm = TRUE)
  num_gross <- sum(sel$DecisionError, na.rm = TRUE)
  
  gross_errors <- sprintf('\nThe errors that may change statistical significance were reported as:\n%s\n',
                          paste0(sel$Raw[sel$DecisionError],
                                 ' (recalculated p-value: ',
                                 round(sel$Computed[sel$DecisionError], 5),
                                 ')',
                                 collapse = '\n'))
  
  errors <- sprintf("\nThe errors that may affect the computed p-value (but not the statistical significance) were reported as:\n%s\n",
                    paste0(sel$Raw[sel$Error & !sel$DecisionError],
                           ' (recalculated p-value: ',
                           round(sel$Computed[sel$Error & !sel$DecisionError], 5),
                           ')',
                           collapse = '\n'))
  
  txt <- sprintf("Using the R package statcheck (v1.0.2), the HTML version of this article was scanned on 2016-06-11 for statistical results (t, r, F, Chi2, and Z values) reported in APA format (for specifics, see Nuijten et al., 2015). An automatically generated report follows.

The scan detected %s statistical results in APA format, of which %s contained potentially incorrect statistical results, of which %s may change statistical significance (α = .05). Potential one-tailed results were taken into account when 'one-sided', 'one-tailed', or 'directional' occurred in the text.
%s%s
Note that these are not definitive results and require manual inspection to definitively assess whether results are erroneous.

Reference
Nuijten, M. B., Hartgerink, C. H. J., van Assen, M. A. L. M., Epskamp, S., & Wicherts, J. M. (2015). The prevalence of statistical reporting errors in psychology (1985-2013). Behavior Research Methods. http://dx.doi.org/10.3758/s13428-015-0664-2",
                 num_res,
                 num_error,
                 num_gross,
                 ifelse(gross_errors == "\nThe errors that may change statistical significance were reported as:\n (recalculated p-value: )\n",
                        "",
                        gross_errors),
                 ifelse(errors == "\nThe errors that may affect the computed p-value (but not the statistical significance) were reported as:\n (recalculated p-value: )\n",
                        "",
                        errors))
  
  write.table(txt,
              file = paste0('reports/',
                            gsub(pattern = '/',
                                 replacement = '_',
                                 uniq[i])),
              col.names = FALSE, row.names = FALSE, quote = FALSE)
}
