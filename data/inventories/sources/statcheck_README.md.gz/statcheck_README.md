# Dataset of statcheck for all APA journals

License does not apply to original articles.

Before running the below, run all the codes available in the [scraping/README.md](scraping/README.md), with the scraping directory as the working directory.

This is the command used to extract the results from each article with `statcheck` (see [`statcheck_version`](statcheck_version) for version info). It utilizes [this](statcheck.R) script for parsimony sake.

```bash
Rscript statcheck.R scraping/metadata/apa_metadata_plus.csv apa
Rscript statcheck.R scraping/metadata/sage_metadata_plus.csv sage
Rscript statcheck.R scraping/metadata/springer_metadata_plus.csv springer
Rscript statcheck.R scraping/metadata/taylorfrancis_metadata_plus.csv taylorfrancis

# Remove those articles for which no metadata was available
# These all went into the same file (overwrite)
rm statcheck/NA.csv statcheck/nodoi*
```

And then to join back all individual statcheck files into one big dataset called `statcheck_dataset.csv`. Also include a test dataset, which is less humongous.

```bash
cat df_names_statcheck $(ls statcheck/ | grep -v nodoi  | sed -e 's/^/statcheck\//') > statcheck_dataset.csv
head -n 1000 statcheck_dataset.csv > statcheck_testset.csv
```

## Flowchart numbers

In order to get the flowchart numbers, run these commands (some won't work with repo because I cannot share the original articles)

```bash
# Journals
cat scraping/journal-spiders/journal_list.csv | grep -oP apa | wc -l
cat scraping/journal-spiders/journal_list.csv | grep -oP sage | wc -l
cat scraping/journal-spiders/journal_list.csv | grep -oP springer | wc -l
cat scraping/journal-spiders/journal_list.csv | grep -oP taylorfrancis | wc -l

# Journals with links
cat scraping/journal-spiders/journal_list.csv | grep -P ,1, | grep -oP apa | wc -l
cat scraping/journal-spiders/journal_list.csv | grep -P ,1, | grep -oP sage | wc -l
cat scraping/journal-spiders/journal_list.csv | grep -P ,1, | grep -oP springer | wc -l
cat scraping/journal-spiders/journal_list.csv | grep -P ,1, | grep -oP taylorfrancis | wc -l

# URLs extracted
cat scraping/journal-spiders/journal-links/apa* | wc -l
cat scraping/journal-spiders/journal-links/sage* | wc -l
cat scraping/journal-spiders/journal-links/springer* | wc -l
cat scraping/journal-spiders/journal-links/taylorfrancis* | wc -l

# URLs downloaded
ls scraping/html/apa_articles/ | wc -l
ls -R scraping/html/sage_articles/ | grep -oP fulltext.html | wc -l
ls -R scraping/html/springer_articles/ | grep -oP fulltext.html | wc -l
ls -R scraping/html/taylorfrancis_articles/ | grep -oP fulltext.html | wc -l

# Articles with results
# Results extracted
# see table.R
Rscript table.R
```

## Notes

Removed some links. Does not necessitate unsuccessful download.

```bash
# Closed access upon download
http://link.springer.com/article/10.1186/2193-7680-2-6
http://link.springer.com/article/10.1186/s40359-014-0034-3
http://link.springer.com/article/10.1186/s40359-014-0028-1
http://link.springer.com/article/10.1186/s40359-014-0030-7

# Removed because it got stuck
# Might have completed download nonetheless
http://www.tandfonline.com/doi/full/10.1080/10413200701599173#abstract
```